Sample Corpora
====================
A number of text corpora for training different algorithms

Existing corpora

* English conversations (Berkeley)
* Deceleration of independence 
* State of the Union Addresses (1790-2012)
* Works of William Shakespeare


Ideas for other texts
--------------------------
* Project Gutenberg

