clc;

close all;
clear all;

%discremeinateanalysis
linearRegression
%logisticregression
naivbayes
regresstree
ccaregression
svm