Modules
==============
* Naive Bayes
* logistic regression
* mlogit
* SVM
