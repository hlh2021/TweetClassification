If you use these functions I'd appreciate a link back to my paper:

Using Canonical Correlation Analysis for Generalized Sentiment Analysis, Product Recommendation and Search, Faridani, S., RecSys, pp 355-358, 2011. 
http://ieor.berkeley.edu/~faridani/papers/doc01-faridani.pdf

