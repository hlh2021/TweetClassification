function output = tokenize_cell_array(cellarray, num_headers) 

% Takes a cell array, one entry per line and tokenizes it


end
