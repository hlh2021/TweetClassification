function out1 = SanitizeKey(in1)
    % clears a string from puctuations
    
    in1 = lower(char(in1));
    
    res = regexprep(regexprep(regexprep(regexprep(regexp(in1, ', [0-9\.]{4,}','split'), '; ', ''), '^ +', ''), ' +$', ''), '[^\w\s]','');
    
    out1 = res(1 : end - 1);
    
    