term = 'a way of swimming by lying on your front and moving your arms together over your head while your legs move up and down'

n_grams(term, 5)