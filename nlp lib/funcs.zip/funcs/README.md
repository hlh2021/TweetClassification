Modules
================
* F-score
* cross validation
* Precision 
* Recall
* Fallout

For other statiscital measures use t-test and chi-square implementations from Matlab


