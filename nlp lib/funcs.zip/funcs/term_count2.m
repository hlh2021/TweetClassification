function output = term_count2(inputtext, headers, max_doc_length)
% Multinomial Featurizer
%
% takes:
%      inputtext: a long string
%      headers: a cell array containing a number of keywords
% output:
%      an array of numbers
%      showing how many times each term is repeated in the text
output = zeros(size(headers,2), max_doc_length);
for j = 1 : min(max_doc_length, length(inputtext))
    for i= 1:size(headers,2)
        pattern = headers{i};
                
        if strcmp(inputtext{j}, pattern);
            
            output(i, j) = output(i, j) + 1;
            
        end
        
        %inputtext = regexprep(inputtext, pattern, ' '); %removes the terms for efficiency 
    end
end
end
