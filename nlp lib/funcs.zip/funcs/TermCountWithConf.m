function output = TermCountWithConf(inputtext, headers, conf)
% Multinomial Featurizer
%
% takes:
%      inputtext: a long string
%      headers: a cell array containing a number of keywords
% output:
%      an array of numbers
%      showing how many times each term is repeated in the text
output = zeros(1, length(headers));
for j = 1 :length(inputtext)
    for i= 1:size(headers,2)
        pattern = headers{i};
                
        if strcmp(inputtext{j}, pattern);
            
            if j > length(conf)
                a = 0;
            end
            
            output(1, i) = str2double(conf{j});
            break;
        end
        
        %inputtext = regexprep(inputtext, pattern, ' '); %removes the terms for efficiency 
    end
end
end
